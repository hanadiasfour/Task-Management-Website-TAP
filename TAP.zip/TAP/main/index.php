<?php 
header("Location:tapSys.php");
exit;
?>